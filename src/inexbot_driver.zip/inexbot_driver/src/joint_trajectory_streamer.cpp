/*
 * Software License Agreement (BSD License)
 *
 * Copyright (c) 2011, Southwest Research Institute
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 	* Redistributions of source code must retain the above copyright
 * 	notice, this list of conditions and the following disclaimer.
 * 	* Redistributions in binary form must reproduce the above copyright
 * 	notice, this list of conditions and the following disclaimer in the
 * 	documentation and/or other materials provided with the distribution.
 * 	* Neither the name of the Southwest Research Institute, nor the names
 *	of its contributors may be used to endorse or promote products derived
 *	from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "abb_driver/joint_trajectory_streamer.h"
#include <iostream>
#include <fstream>

using industrial::simple_message::SimpleMessage;

namespace industrial_robot_client
{
namespace joint_trajectory_streamer
{

// bool JointTrajectoryStreamer::init(std::string default_ip, int default_port)
bool JointTrajectoryStreamer::init(SmplMsgConnection* connection, const std::vector<std::string> &joint_names,
                                   const std::map<std::string, double> &velocity_limits)
{
  bool rtn = true;

  ROS_INFO("JointTrajectoryStreamer: init");

  // rtn &= JointTrajectoryInterface::init(default_ip, default_port);
  rtn &= JointTrajectoryInterface::init(connection, joint_names, velocity_limits);

  // std::ofstream myout("/home/neil/bg.txt");
  // myout<< "rtn:" << rtn << std::endl;
  // myout.close();

  this->mutex_.lock();
  this->current_point_ = 0;
  this->state_ = TransferStates::IDLE;
  this->streaming_thread_ =
      new boost::thread(boost::bind(&JointTrajectoryStreamer::streamingThread, this));
  ROS_INFO("Unlocking mutex");
  this->mutex_.unlock();

  return rtn;
}



JointTrajectoryStreamer::~JointTrajectoryStreamer()
{
  delete this->streaming_thread_;
}

void JointTrajectoryStreamer::jointTrajectoryCB(const trajectory_msgs::JointTrajectoryConstPtr &msg)
{
  ROS_INFO("Receiving joint trajectory message");

  // read current state value (should be atomic)
  const auto state = this->state_;

  ROS_DEBUG("Current state is: %d", state);

  // always request a stop of current trajectory execution if an empty trajectory
  // is received. We handle this separately from the check below, as the server
  // might be executing a trajectory which this client has already finished
  // uploading (due to buffering on the server side fi), and then our local state
  // would be "IDLE", and we'd end up not sending the stop request.
  if (msg->points.empty())
  {
    ROS_INFO_STREAM("Empty trajectory received while in state: " << TransferStates::to_string1(state) << ". Canceling current trajectory.");
    this->mutex_.lock();
    trajectoryStop();
    this->mutex_.unlock();
    return;
  }

  // if we're currently streaming a trajectory and we're requested to stream another
  // we complain, as splicing is not supported. Cancellation of the current trajectory
  // should first be requested, then a new trajectory started.
  if (TransferStates::IDLE != state)
  {
    ROS_ERROR("Trajectory splicing not yet implemented, stopping current motion.");
    this->mutex_.lock();
    trajectoryStop();
    this->mutex_.unlock();
    return;
  }

  // calc new trajectory
  std::vector<JointTrajPtFullMessage> new_traj_msgs;
  if (!trajectory_to_msgs(msg, &new_traj_msgs))
    return;

  // std::ofstream myout("/home/neil/bg.txt");
  // myout<< "1111" << std::endl;
  // myout.close();

  // send command messages to robot
  send_to_robot(new_traj_msgs);
}

bool JointTrajectoryStreamer::send_to_robot(const std::vector<JointTrajPtFullMessage>& messages)
{
  ROS_INFO("Loading trajectory, setting state to streaming");

  // std::ofstream myout("/home/neil/bg1.txt");
  // myout<< "1111" << std::endl;
  // myout.close();

  this->mutex_.lock();
  {
    ROS_INFO("Executing trajectory of size: %d", (int)messages.size());
    this->current_traj_ = messages;
    this->current_point_ = 0;
    this->state_ = TransferStates::STREAMING;
    this->streaming_start_ = ros::Time::now();
    
    // std::ofstream myout("/home/neil/bg2.txt");
    // myout<< "2222" << std::endl;
    // myout.close();
  }
  this->mutex_.unlock();

  // std::ofstream myout3("/home/neil/bg3.txt");
  // myout3<< "3333" << std::endl;
  // myout.close();

  return true;
}

bool JointTrajectoryStreamer::trajectory_to_msgs(const trajectory_msgs::JointTrajectoryConstPtr &traj, std::vector<JointTrajPtFullMessage>* msgs)
{
  // use base function to transform points
  if (!JointTrajectoryInterface::trajectory_to_msgs(traj, msgs))
    return false;

  // pad trajectory as required for minimum streaming buffer size
  if (!msgs->empty() && (msgs->size() < (size_t)min_buffer_size_))
  {
    ROS_DEBUG("Padding trajectory: current(%d) => minimum(%d)", (int)msgs->size(), min_buffer_size_);
    while (msgs->size() < (size_t)min_buffer_size_)
      msgs->push_back(msgs->back());
  }

  // std::ofstream myout("/home/neil/bg2.txt");
  // myout<< "2222" << std::endl;
  // myout.close();

  return true;
}

int a=0;
int b=0;

void JointTrajectoryStreamer::streamingThread()
{
  JointTrajPtFullMessage jtpMsg;
  int connectRetryCount = 1;

  std::ofstream myout1("/home/neil/bg1.txt",std::ofstream::app);
  std::ofstream myout2("/home/neil/bg2.txt",std::ofstream::app);
  std::ofstream myout3("/home/neil/bg3.txt",std::ofstream::app);
  std::ofstream myout4("/home/neil/bg4.txt",std::ofstream::app);
  std::ofstream myout5("/home/neil/bg5.txt",std::ofstream::app);
  std::ofstream myout6("/home/neil/bg6.txt",std::ofstream::app);
  std::ofstream myout7("/home/neil/bg7.txt",std::ofstream::app);
  std::ofstream myout8("/home/neil/bg8.txt",std::ofstream::app);
  std::ofstream myout9("/home/neil/bg9.txt",std::ofstream::app);
  std::ofstream myout10("/home/neil/bg10.txt",std::ofstream::app);

  ROS_INFO("Starting joint trajectory streamer thread");
  
  while (ros::ok())
  {
    ros::Duration(0.5).sleep();

    // automatically re-establish connection, if required
    if (connectRetryCount-- > 0)
    {
      ROS_INFO("Connecting to robot motion server");
      this->connection_->makeConnect();
      ros::Duration(0.50).sleep();  // wait for connection

      if (this->connection_->isConnected())
      {
        connectRetryCount = 0;
        
        myout1<< "1111" << std::endl;
        myout1.close();
      }
      else if (connectRetryCount <= 0)
      {
        ROS_ERROR("Timeout connecting to robot controller.  Send new motion command to retry.");
        this->state_ = TransferStates::IDLE;
      }
      continue;
    }
    b++;
    myout2<< "2222,b="<< b << std::endl;
    myout2.close();

    this->mutex_.lock();

    SimpleMessage msg, reply;

    switch (this->state_)
    {
      case TransferStates::IDLE:
        ros::Duration(0.010).sleep();  //  loop while waiting for new trajectory
        myout3<< "3333" << std::endl;
        myout3.close();
        break;

      case TransferStates::STREAMING:
        if (this->current_point_ >= (int)this->current_traj_.size())
        {
          ROS_INFO("Trajectory streaming complete, setting state to IDLE");
          this->state_ = TransferStates::IDLE;
          myout4<< "4444"<< this->current_point_ << (int)this->current_traj_.size() << std::endl;
          myout4.close();
          break;
        }

        if (!this->connection_->isConnected())
        {
          ROS_DEBUG("Robot disconnected.  Attempting reconnect...");
          connectRetryCount = 5;
          myout5<< "5555" << std::endl;
          myout5.close();

          break;
        }

        jtpMsg = this->current_traj_[this->current_point_];
        // jtpMsg.toRequest(msg);
        jtpMsg.toTopic(msg);
        myout6<< "6666,msg=" << std::endl;
        myout6.close();

        ROS_DEBUG("Sending joint trajectory point");
        // if (this->connection_->sendAndReceiveMsg(msg, reply, false))
        if (this->connection_->sendMsg(msg))
        {
          a++;
          this->current_point_++;
          ROS_INFO("Point[%d of %d] sent to controller",
                   this->current_point_, (int)this->current_traj_.size());

          myout7<< "7777,a="<< a << "current"<< this->current_point_ << std::endl;
          myout7.close();
        }
        else {
          ROS_WARN("Failed sent joint point, will try again");
          myout8<< "8888" << std::endl;
          myout8.close();
        }
          
        break;
      default:
        ROS_ERROR("Joint trajectory streamer: unknown state");
        this->state_ = TransferStates::IDLE;
        myout9<< "9999" << std::endl;
        myout9.close();

        break;
    }

    this->mutex_.unlock();
  }

  
  myout10<< "1010" << std::endl;
  myout10.close();

  ROS_WARN("Exiting trajectory streamer thread");
}

void JointTrajectoryStreamer::trajectoryStop()
{
  JointTrajectoryInterface::trajectoryStop();

  ROS_DEBUG("Stop command sent, entering idle mode");
  this->state_ = TransferStates::IDLE;
}

} //joint_trajectory_streamer
} //industrial_robot_client

